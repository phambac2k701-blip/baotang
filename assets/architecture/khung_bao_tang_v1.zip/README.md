# Khung bảo tàng ba thùy lệch — V1

Phương án để duyệt hình khối và bố cục trước khi tìm vật liệu. Chưa thay thế thiết kế cốt truyện hoặc các tài liệu trong repo.

- Tổng diện tích bao sàn hai tầng: 263,924 m²; mỗi tầng 131,962 m². Có tính vùng tường và thang, trừ giếng trời; không đồng nghĩa diện tích sử dụng.
- Hình bao ngoài: 16,025 × 12,993 m. Giếng trời ellipse: 6,00 × 4,20 m, lệch tâm.
- Các gian trưng bày là một dải mở rộng biến thiên quanh lõi; phòng phụ chỉ nằm ở một phía.
- Cao độ sàn: 0 và 3,65 m. Trần thông thủy 3,40 m; sàn/mái dày 0,25 m; mái 7,30 m.
- 01: mặt bằng hai tầng, cửa, cửa sổ, các phòng và kích thước chính.
- 02: bốn góc từ cùng bộ tọa độ, không có vật liệu hoặc đồ nội thất.
- 03: cao độ, diện tích và hình bao từng phòng cong. Hình bao phòng không phải chiều dài/rộng một phòng chữ nhật.
- geometry.json: công thức và 720 điểm của mỗi đường cong, cao độ, bề dày, khoảng góc của các ô mở và phòng. Đây là nguồn để AI dựng theo; hình concept có thể lệch chi tiết.
- draw_shell.py: tái tạo bản vẽ bằng Python/numpy/matplotlib. Không phải scene Blender hay bản game đã chạy.

Các mục còn cần kiểm chứng bằng blockout chơi được: khoảng đi sau khi thêm đồ, kích thước khu phục chế/kho hồ sơ nhỏ, bề dày các góc giao vách, thang và che chắn thang công cộng để giữ mạch khám phá tầng 2. Lối bí mật dùng một ô xuống thang đứng riêng dưới P0; vách khu thoát tầng dưới sẽ bổ sung khi chốt phương án.

Ý tưởng nghiên cứu: tuyến xem liên tục ở Guggenheim (https://franklloydwright.org/site/solomon-r-guggenheim-museum/) và cách dùng tường cong thay đổi trải nghiệm gian ở Kiasma (https://www.stevenholl.com/project/kiasma-museum/). Hình khối này là phương án riêng, không sao chép hai công trình.
