from pathlib import Path
import json, math, zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Rectangle, Arc
from matplotlib.path import Path as MPath
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

ROOT=Path(__file__).parent
N=720
t=np.linspace(0,2*np.pi,N,endpoint=False)
r=1+.16*np.cos(3*(t-.15))+.07*np.sin(2*t)
outer=np.c_[7.8*r*np.cos(t),6.1*r*np.sin(t)]
inner=np.c_[.55+3*np.cos(t),.25+2.1*np.sin(t)]
def curve(deg,u=1):
    a=np.deg2rad(np.asarray(deg)); rr=1+.16*np.cos(3*(a-.15))+.07*np.sin(2*a)
    o=np.stack([7.8*rr*np.cos(a),6.1*rr*np.sin(a)],axis=-1)
    i=np.stack([.55+3*np.cos(a),.25+2.1*np.sin(a)],axis=-1)
    return i+(o-i)*u
def area(a): return abs(np.sum(a[:,0]*np.roll(a[:,1],-1)-a[:,1]*np.roll(a[:,0],-1)))/2
gross=area(outer)-area(inner)
rooms=[('P0',100,130,.43,'Phòng tỉnh dậy'),('P1',75,100,.43,'Kho hồ sơ'),('P2',45,75,.43,'Phòng phục chế'),('P3',-20,45,.35,'Gian câu đố')]
stairs=(-6.5,-3.6,-3.6,.1)
def sector(a,b,u):
    q=np.linspace(a,b,80)
    return np.vstack([curve(q,1),curve(q[::-1],u)])
def dim(ax,p,q,txt,off=(0,0)):
    p=np.array(p)+off;q=np.array(q)+off
    ax.annotate('',q,p,arrowprops=dict(arrowstyle='<->',color='#526278',lw=.85))
    mid=(p+q)/2; ax.text(*mid,txt,ha='center',va='center',fontsize=8,color='#263951',bbox=dict(facecolor='white',edgecolor='none',pad=1.8))
def door_curve(ax,angle,u,width,color='#fff'):
    p=curve(angle,u); ds=np.linalg.norm(curve(angle+.1,u)-curve(angle-.1,u))/.2
    half=width/(2*ds);line=curve(np.linspace(angle-half,angle+half,12),u)
    ax.plot(*line.T,color=color,lw=5,zorder=7)
    ax.plot(*line.T,color='#3b7d9c',lw=1.1,ls='--',zorder=8)
    return [float(angle-half),float(angle+half)]
window_angles=[-150,-115,-65,-35,10,150]
window_width=1.3
ports={0:[(-90,2.4,0,2.7),(115,1.2,0,2.4)],1:[]}
for floor in ports:
    ports[floor]+=[(a,window_width,1.5,3.0) for a in window_angles]
port_intervals={}
for floor,items in ports.items():
    port_intervals[floor]=[]
    for a,w,z0,z1 in items:
        ds=np.linalg.norm(curve(a+.1)-curve(a-.1))/.2
        half=w/(2*ds);port_intervals[floor].append((a-half,a+half,z0,z1))

plt.rcParams['font.family']='DejaVu Sans'
fig=plt.figure(figsize=(18,11),facecolor='#f5f7fa')
fig.text(.035,.955,'BẢO TÀNG BA THÙY LỆCH — KHUNG KIẾN TRÚC V1',fontsize=21,weight='bold',color='#203349')
fig.text(.035,.922,'Mặt bằng có số đo • đơn vị mét • hai tầng • chưa bố trí hiện vật hoặc vật liệu',fontsize=11,color='#526278')
for floor,pos in [(0,[.035,.16,.35,.72]),(1,[.405,.16,.35,.72])]:
    ax=fig.add_axes(pos);ax.set_aspect('equal');ax.set_facecolor('white')
    ax.add_patch(Polygon(outer,facecolor='#eef2f6',edgecolor='#22354b',lw=2.3))
    ax.add_patch(Polygon(inner,facecolor='white',edgecolor='#22354b',lw=2.0))
    # True wall thickness is inward from outer boundary / outward from lightwell boundary.
    for pts,sign in [(outer,-1),(inner,1)]:
        tangent=np.roll(pts,-1,axis=0)-np.roll(pts,1,axis=0);normal=np.c_[tangent[:,1],-tangent[:,0]]
        normal/=np.linalg.norm(normal,axis=1)[:,None]; pp=pts+sign*.2*normal
        ax.plot(*np.vstack([pp,pp[0]]).T,color='#657589',lw=.6)
    if floor==1:
        for key,a,b,u,label in rooms:
            poly=sector(a,b,u);ax.add_patch(Polygon(poly,facecolor='#e1e7ed',edgecolor='#26394f',lw=1.3))
            mid=curve((a+b)/2,(u+1)/2)
            ax.text(*mid,key,fontsize=10,ha='center',weight='bold',color='#21384d')
            door_curve(ax,(a+b)/2,u,1.2 if key=='P3' else 1.0)
        # concealed hatch lies under future bed, inside P0, no furniture added.
        h=curve(116,.72);ax.add_patch(Rectangle((h[0]-.5,h[1]-.65),1,1.3,fill=False,ls='--',lw=1,color='#946436'))
        ax.text(h[0],h[1]-.9,'H',fontsize=8,ha='center',color='#946436')
    x0,x1,y0,y1=stairs
    ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,facecolor='#d9e0e8',edgecolor='#26394f',lw=1))
    for yy in np.linspace(y0+.1,y1-.95,11):
        ax.plot([x0+.12,(x0+x1)/2-.1],[yy,yy],color='#718196',lw=.45)
        ax.plot([(x0+x1)/2+.1,x1-.12],[yy,yy],color='#718196',lw=.45)
    ax.plot([(x0+x1)/2,(x0+x1)/2],[y0,y1-.95],color='#718196',lw=.65)
    ax.text((x0+x1)/2,(y0+y1)/2,'S1',ha='center',fontsize=9,color='#21384d')
    for angle,width,z0,z1 in ports[floor]: door_curve(ax,angle,1,width)
    ax.text(.55,.25,'GIẾNG TRỜI\n6,00 × 4,20 m\nkhông tính diện tích sàn',ha='center',va='center',fontsize=9,color='#526278')
    ax.text(-1,-4.25,'DẢI TRƯNG BÀY MỞ\nkhông chia phòng kín',ha='center',fontsize=10,weight='bold',color='#203c53')
    if floor==0:
        ax.text(3.0,3.6,'Không gian mở\ntầng dưới',ha='center',fontsize=9,color='#526278')
        ax.annotate('D0 • cửa chính 2,40 m',curve(-90),(-.8,-9),ha='center',fontsize=8,arrowprops=dict(arrowstyle='-',color='#657589'))
        ax.annotate('D1 • cửa hậu 1,20 m',curve(115),(-6,7.5),ha='center',fontsize=8,arrowprops=dict(arrowstyle='-',color='#657589'))
    else: ax.text(1.0,3.3,'lối nối qua khu phụ',ha='center',fontsize=8,color='#526278')
    lo=outer.min(axis=0);hi=outer.max(axis=0)
    dim(ax,[lo[0],-8],[hi[0],-8],f'{hi[0]-lo[0]:.2f} m')
    dim(ax,[10.5,lo[1]],[10.5,hi[1]],f'{hi[1]-lo[1]:.2f} m')
    ax.plot([0,5],[-9.8,-9.8],color='#22354b',lw=2);ax.text(2.5,-10.15,'thước chuẩn 5 m',ha='center',fontsize=8)
    ax.annotate('',(8.7,7.4),(8.7,6.0),arrowprops=dict(arrowstyle='-|>',color='#26394f'));ax.text(8.7,7.65,'BẮC',ha='center',fontsize=8)
    ax.set_xlim(-8.4,11.6);ax.set_ylim(-10.7,8.4);ax.axis('off')
    ax.set_title(f'TẦNG {floor+1} — cao độ +{floor*3.65:.2f} m',fontsize=13,weight='bold',pad=18,color='#203349')
ax=fig.add_axes([.785,.13,.19,.75]);ax.axis('off')
lines=[('QUY MÔ',True), (f'Bao ngoài: 16,03 × 12,99 m',False),(f'Sàn mỗi tầng: {gross:.2f} m² (*)',False),(f'Tổng hai tầng: {2*gross:.2f} m² (*)',False),('Giếng trời: 19,79 m²',False),('',False),('MẶT CẮT / KẾT CẤU GAME',True),('Sàn tầng 1: ±0,00 m',False),('Sàn tầng 2: +3,65 m',False),('Đỉnh mái: +7,30 m',False),('Đỉnh lan can mái: +7,65 m',False),('Chiều cao thông thủy: 3,40 m',False),('Sàn/mái dày: 0,25 m',False),('Tường vỏ: 0,20 m',False),('Vách khu phụ: 0,12 m',False),('',False),('CỬA / CỬA SỔ',True),('D0: 2,40 × 2,70 m',False),('D1: 1,20 × 2,40 m',False),('Cửa P0/P1/P2: 1,00 × 2,40 m',False),('Cửa P3: 1,20 × 2,40 m',False),('W01–W06 / tầng: 1,30 × 1,50 m',False),('Bậu cửa sổ: +1,50 m / sàn',False),('Tường giếng trời kín; không',False),('có ban công nhìn xuống tầng 1.',False),('',False),('KHU PHỤ TẦNG 2',True),('P0: phòng tỉnh dậy',False),('P1: kho hồ sơ',False),('P2: phòng phục chế',False),('P3: gian câu đố / cửa sập',False),('S1: thang công cộng 2,90 × 3,70 m',False),('H: ô bí mật 1,00 × 1,30 m',False)]
y=1
for txt,bold in lines:
    ax.text(0,y,txt,fontsize=9 if not bold else 10,weight='bold' if bold else 'normal',color='#203349' if bold else '#526278');y-=.029
fig.text(.035,.075,'(*) Diện tích theo hình bao sàn, gồm vùng tường và vùng thang; trừ giếng trời. Diện tích sử dụng thực tế nhỏ hơn.',fontsize=9,color='#526278')
fig.text(.035,.05,'Đường xanh đứt = ô mở. Đường nâu đứt = ô bí mật dự kiến. Dải bên trong khu phụ vẫn nối các gian; phòng câu đố có thể đi vòng.',fontsize=9,color='#526278')
fig.text(.035,.025,'Đây là bản phác thảo kiến trúc cho game; tọa độ đường cong và các ô mở nằm trong geometry.json để dựng nhất quán.',fontsize=9,color='#526278')
fig.savefig(ROOT/'01_mat_bang_kich_thuoc.png',dpi=180);plt.close(fig)

# Build a deterministic, empty shell for explanatory reference views.
def floor_faces(z):
    return [[[*inner[j],z],[*outer[j],z],[*outer[(j+1)%N],z],[*inner[(j+1)%N],z]] for j in range(0,N,4) for _ in []]
def floor_mesh(z):
    out=[]
    for j in range(0,N,4):
        k=(j+4)%N;quad=[[*inner[j],z],[*outer[j],z],[*outer[k],z],[*inner[k],z]]
        center=(inner[j]+outer[j]+outer[k]+inner[k])/4
        if abs(z-3.65)<.01 and stairs[0]<center[0]<stairs[1] and stairs[2]<center[1]<stairs[3]: continue
        out.append(quad)
    return out
def wall_quad(a,b,z0,z1): return [[*a,z0],[*b,z0],[*b,z1],[*a,z1]]
def outer_walls(floor):
    out=[];z=floor*3.65
    for j in range(0,N,4):
        k=(j+4)%N;ang=np.rad2deg(t[j])+1
        ang=(ang+180)%360-180;holes=[]
        for lo,hi,z0,z1 in port_intervals[floor]:
            if lo<=ang<=hi: holes.append((z0,z1))
        spans=[(0,3.4)] if not holes else [(0,holes[0][0]),(holes[0][1],3.4)]
        for z0,z1 in spans:
            if z1>z0: out.append(wall_quad(outer[j],outer[k],z+z0,z+z1))
    return out
def inner_walls(floor):
    z=floor*3.65;return [wall_quad(inner[j],inner[(j+4)%N],z,z+3.4) for j in range(0,N,4)]
def room_walls():
    out=[];z=3.65
    for key,a,b,u,_ in rooms:
        q=np.linspace(a,b,35);p=curve(q,u)
        center=(a+b)/2;ds=np.linalg.norm(curve(center+.1,u)-curve(center-.1,u))/.2
        half=(1.2 if key=='P3' else 1)/(2*ds)
        for j in range(len(q)-1):
            if abs((q[j]+q[j+1])/2-center)<half: out.append(wall_quad(p[j],p[j+1],z+2.4,z+3.4))
            else:out.append(wall_quad(p[j],p[j+1],z,z+3.4))
        for deg in [a,b]:out.append(wall_quad(curve(deg,u),curve(deg,1),z,z+3.4))
    return out
def add(ax,faces,col,edge='#77818c',lw=.16):
    ax.add_collection3d(Poly3DCollection(faces,facecolors=col,edgecolors=edge,linewidths=lw))
def draw3d(ax,elev,azim,mode='cut'):
    add(ax,floor_mesh(0),'#d9dee4');add(ax,outer_walls(0),'#f7f7f5');add(ax,inner_walls(0),'#e7eaee')
    add(ax,floor_mesh(3.65),'#d4dae2');add(ax,outer_walls(1),'#f7f7f5');add(ax,inner_walls(1),'#e7eaee');add(ax,room_walls(),'#eef0f2')
    if mode=='roof':add(ax,floor_mesh(7.3),'#dde2e8')
    x0,x1,y0,y1=stairs
    xm=(x0+x1)/2
    for j in range(11):
        yy=y0+.25*j;zz=3.65*(j+1)/22
        add(ax,[[[x0,yy,zz],[xm-.1,yy,zz],[xm-.1,yy+.25,zz],[x0,yy+.25,zz]]],'#c6ced9',lw=.3)
        yy=y0+.25*(10-j);zz=3.65*(j+12)/22
        add(ax,[[[xm+.1,yy,zz],[x1,yy,zz],[x1,yy+.25,zz],[xm+.1,yy+.25,zz]]],'#c6ced9',lw=.3)
    add(ax,[[[x0,y0+2.75,1.825],[x1,y0+2.75,1.825],[x1,y1,1.825],[x0,y1,1.825]]],'#c6ced9',lw=.3)
    ax.set_xlim(-8,10);ax.set_ylim(-8,7);ax.set_zlim(0,8);ax.set_box_aspect((18,15,8));ax.view_init(elev,azim);ax.set_axis_off();ax.set_proj_type('ortho')
fig=plt.figure(figsize=(16,13),facecolor='white')
views=[(58,-60,'01 • CẮT MÁI / NHÌN TỪ ĐÔNG NAM','cut'),(35,130,'02 • CẮT MÁI / NHÌN TỪ TÂY BẮC','cut'),(25,-95,'03 • MẶT TIỀN / MÁI ĐẶT LẠI','roof'),(75,20,'04 • MẶT BẰNG KHỐI / CẮT MÁI','cut')]
for k,(el,az,title,mode) in enumerate(views):
    ax=fig.add_subplot(2,2,k+1,projection='3d');draw3d(ax,el,az,mode);ax.set_title(title,fontsize=11,color='#203349',pad=-6)
fig.suptitle('CÙNG MỘT KHUNG NHÀ — NHIỀU GÓC NHÌN',fontsize=19,weight='bold',color='#203349',y=.975)
fig.text(.5,.025,'Khung trắng • hai tầng • không đồ nội thất • không texture • giếng trời không thông vào không gian trưng bày',ha='center',fontsize=10,color='#526278')
fig.subplots_adjust(top=.94,bottom=.05,wspace=-.08,hspace=-.05);fig.savefig(ROOT/'02_khung_nhieu_goc.png',dpi=160);plt.close(fig)
# Isolated large perspective, used as geometry reference by imagegen.
fig=plt.figure(figsize=(13,10),facecolor='white');ax=fig.add_subplot(projection='3d');draw3d(ax,65,-65,'cut');fig.subplots_adjust(0,0,1,1);fig.savefig(ROOT/'reference_shell.png',dpi=160);plt.close(fig)
data={'title':'Bảo tàng ba thùy lệch V1','units':'meters','scope':'game architectural draft, not construction design','outer_curve_formula':'theta in radians; r=1+0.16*cos(3*(theta-0.15))+0.07*sin(2*theta); x=7.8*r*cos(theta); y=6.1*r*sin(theta)','inner_curve_formula':'x=0.55+3.0*cos(theta); y=0.25+2.1*sin(theta)','outer_boundary_xy':outer.round(6).tolist(),'lightwell_boundary_xy':inner.round(6).tolist(),'floor_levels':[0,3.65],'clear_height':3.4,'slab_thickness':.25,'roof_level':7.3,'parapet_top':7.65,'outer_wall_thickness_inward':.2,'lightwell_wall_thickness_outward':.2,'partition_thickness':.12,'gross_area_one_floor_excluding_lightwell':gross,'gross_area_two_floor':2*gross,'bbox_min_xy':outer.min(axis=0).tolist(),'bbox_max_xy':outer.max(axis=0).tolist(),'room_rule':'curve(theta,u)=inner(theta)+u*(outer(theta)-inner(theta)); room is the strip u..1 over angle interval; upper floor only','upper_rooms':[{'id':k,'label':l,'theta_start_deg':a,'theta_end_deg':b,'inner_u':u,'door_center_theta_deg':(a+b)/2,'door_width':1.2 if k=='P3' else 1.,'door_height':2.4} for k,a,b,u,l in rooms],'outer_openings':{str(k):[{'theta_center_deg':a,'width_along_curve':w,'local_z_min':z0,'local_z_max':z1,'theta_interval_deg':[lo,hi]} for (a,w,z0,z1),(lo,hi,_,_) in zip(ports[k],port_intervals[k])] for k in ports},'public_stair_bbox':stairs,'public_stair_clear_width_total':2.9,'public_stair_note':'Replace indicative straight stair rendering by a two-flight U stair within its reserved 2.90x3.70m core; floor-to-floor 3.65m; public access blocked in gameplay, not deleted. Headroom and tread fit require subsequent model check.','secret_hatch_center_xy':curve(116,.72).tolist(),'secret_hatch_size':[1,1.3],'secret_route':'H under future bed in P0 -> enclosed private descent aligned below P0 -> D1 ground rear door. Exact private stair profile remains to validate inside P0 and lower service area.','no_furniture':True,'no_materials':True,'no_glazed_atrium_overlook':True,'important':'Area is gross outline excluding lightwell, not usable area; exact staircase detailing is not resolved by this conceptual shell.'}
(ROOT/'geometry.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
data['public_stair_note']='Reserved U stair core 2.90x3.70m; two 1.35m flights around a 0.20m middle gap; 22 indicative risers over 3.65m; game draft, not construction compliance. Public stairs exist but are sealed during the story.'
data['secret_route']='H under future bed in P0 -> vertical private ladder in 1.00x1.30m shaft -> lower rear service zone -> D1. Shaft walls below P0 can be added when detailing the lower exit zone.'
data['room_gross_areas']={key:area(sector(a,b,u)) for key,a,b,u,_ in rooms}
(ROOT/'geometry.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
fig,axes=plt.subplots(1,2,figsize=(16,9),facecolor='white',gridspec_kw={'width_ratios':[1.1,1]})
ax=axes[0];ax.set_aspect('equal');ax.axis('off')
for z in [0,3.65,7.3]:
    ax.add_patch(Rectangle((0,z-.25),16.03,.25,facecolor='#d7dfe8',edgecolor='#354c65',lw=.8))
for x in [0,16.03]: ax.add_patch(Rectangle((x,0),.2,7.3,facecolor='#e6ebf0',edgecolor='#354c65',lw=.8))
for z in [0,3.65]:
    dim(ax,[17.2,z],[17.2,z+3.4],'3,40 m')
    ax.text(1,z+1.6,f'TẦNG {1 if z==0 else 2}\nkhông gian trưng bày',fontsize=11,color='#354c65')
dim(ax,[-1,0],[-1,7.3],'7,30 m');dim(ax,[0,-1],[16.03,-1],'16,03 m')
ax.set_xlim(-3,20);ax.set_ylim(-2,9);ax.set_title('CAO ĐỘ CHUẨN\nSơ đồ cao độ — không phải mặt cắt qua giếng trời',fontsize=12,color='#203349')
ax=axes[1];ax.axis('off');y=.96
for line in ['CÁC ĐƯỜNG CONG ĐƯỢC CHỐT BẰNG TỌA ĐỘ','Vỏ ngoài: đường cong ba thùy, không dùng một bán kính.','Giếng trời: ellipse 6,00 × 4,20 m; tâm (0,55; 0,25).','Hình bao x: −6,9165 → +9,1087 m.','Hình bao y: −6,9900 → +6,0028 m.','720 điểm / đường cong nằm trong geometry.json.','','CÁC PHÒNG KHÔNG PHẢI HỘP CHỮ NHẬT']:
    ax.text(0,y,line,fontsize=10,weight='bold' if line.isupper() else 'normal',color='#354c65');y-=.048
for key,a,b,u,label in rooms:
    q=sector(a,b,u);ext=np.ptp(q,axis=0)
    ax.text(0,y,f'{key} · {label}: {area(q):.2f} m²',fontsize=10,weight='bold',color='#203349');y-=.039
    ax.text(0,y,f'Hình bao {ext[0]:.2f} × {ext[1]:.2f} m; góc {a}° → {b}°.',fontsize=9,color='#526278');y-=.053
for line in ['Diện tích phòng theo hình bao, chưa trừ vách.','Dải đi công cộng nằm phía trong các phòng khu phụ.','Không gộp đường đi này vào diện tích phòng.','','Ô bí mật H: 1,00 × 1,30 m; tâm được ghi trong JSON.','Thang công cộng: lõi chữ U 2,90 × 3,70 m.','Lối bí mật: thang đứng riêng xuống khu cửa hậu.','Vị trí cửa sổ: 6 ô / tầng; xem các khoảng góc trong JSON.']:
    ax.text(0,y,line,fontsize=9,color='#526278');y-=.038
fig.suptitle('BỔ SUNG KÍCH THƯỚC — KHUNG GAME V1',fontsize=18,weight='bold',color='#203349')
fig.subplots_adjust(top=.89,bottom=.06,wspace=.1);fig.savefig(ROOT/'03_cao_do_va_phong.png',dpi=180);plt.close(fig)
print(json.dumps({'gross_per_floor':gross,'gross_total':2*gross,'bbox':np.ptp(outer,axis=0).tolist(),'lightwell':area(inner),'outputs':['01_mat_bang_kich_thuoc.png','02_khung_nhieu_goc.png','reference_shell.png']},ensure_ascii=False))
